#define MPICH_SKIP_MPICXX 1
#define OMPI_SKIP_MPICXX  1
#include "mpi4py.MPE.c"
